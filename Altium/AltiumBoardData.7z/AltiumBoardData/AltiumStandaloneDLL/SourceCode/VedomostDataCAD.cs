// File:    VedomostDataCAD.cs
// Author:  nilov_pg
// Created: 9 августа 2019 г. 15:51:56
// Purpose: Definition of Class VedomostDataCAD

using System;

public class VedomostDataCAD : IBuilderDataCAD
{
}