// File:    IVia.cs
// Author:  nilov_pg
// Created: 24 ноября 2018 г. 16:25:05
// Purpose: Definition of Interface IVia

using System;

public interface IVia
{
   IContour GetIContour();

}