// File:    IVariantCAD.cs
// Author:  nilov_pg
// Created: 20 декабря 2018 г. 10:35:57
// Purpose: Definition of Interface IVariantCAD

using System;

public interface IVariantCAD
{
   IVariant[] GetIVariants();

}