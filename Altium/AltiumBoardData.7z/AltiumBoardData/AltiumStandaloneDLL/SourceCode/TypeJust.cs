// File:    TypeJust.cs
// Author:  Павел
// Created: 11 апреля 2020 г. 18:01:38
// Purpose: Definition of Enum TypeJust

using System;

public enum TypeJust
{
   top,
   bottom,
   left,
   right,
   center,
   lowerLeft,
   lowerRight,
   upperLeft,
   upperRight
}