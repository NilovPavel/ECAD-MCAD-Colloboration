// File:    ICutOut.cs
// Author:  nilov_pg
// Created: 24 ноября 2018 г. 11:39:55
// Purpose: Definition of Interface ICutOut

using System;

public interface ICutOut
{
   IContour GetIContour();

}