// File:    TypeFlip.cs
// Author:  Павел
// Created: 11 апреля 2020 г. 18:01:38
// Purpose: Definition of Enum TypeFlip

using System;

public enum TypeFlip
{
   top,
   bottom
}