// File:    ElementaryComponentID.cs
// Author:  nilov_pg
// Created: 11 декабря 2018 г. 12:54:19
// Purpose: Definition of Class ElementaryComponentID

using System;

public class ElementaryComponentID : ComponentID
{
}