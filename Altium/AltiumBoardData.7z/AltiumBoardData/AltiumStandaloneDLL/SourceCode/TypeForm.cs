// File:    TypeForm.cs
// Author:  Павел
// Created: 11 апреля 2020 г. 18:01:38
// Purpose: Definition of Enum TypeForm

using System;

public enum TypeForm
{
   circle,
   rectangle
}