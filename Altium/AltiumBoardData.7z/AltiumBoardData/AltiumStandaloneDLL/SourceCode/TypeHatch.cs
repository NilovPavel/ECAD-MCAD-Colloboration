// File:    TypeHatch.cs
// Author:  Павел
// Created: 11 апреля 2020 г. 18:01:38
// Purpose: Definition of Enum TypeHatch

using System;

public enum TypeHatch
{
   fillSolid,
   horizontal,
   vertical,
   grid45,
   grid90,
   line45
}