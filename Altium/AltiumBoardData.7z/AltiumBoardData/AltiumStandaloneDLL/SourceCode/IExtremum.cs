// File:    IExtremum.cs
// Author:  nilov_pg
// Created: 15 января 2019 г. 14:25:28
// Purpose: Definition of Interface IExtremum

using System;

public interface IExtremum
{
   Point[] GetExtremums();

}