// File:    IHierarchyCAD.cs
// Author:  nilov_pg
// Created: 11 декабря 2018 г. 12:24:48
// Purpose: Definition of Interface IHierarchyCAD

using System;

public interface IHierarchyCAD
{
   AssemblyComponentID BuildTree();

}