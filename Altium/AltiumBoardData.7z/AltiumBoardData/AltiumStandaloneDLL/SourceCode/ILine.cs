// File:    ILine.cs
// Author:  nilov_pg
// Created: 24 ноября 2018 г. 10:56:57
// Purpose: Definition of Interface ILine

using System;

public interface ILine
{
   Point GetStartPoint();
   
   Point GetEndPoint();

}