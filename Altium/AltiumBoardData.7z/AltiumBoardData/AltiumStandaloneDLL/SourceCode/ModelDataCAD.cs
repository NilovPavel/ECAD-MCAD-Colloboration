// File:    ModelDataCAD.cs
// Author:  nilov_pg
// Created: 9 августа 2019 г. 15:51:57
// Purpose: Definition of Class ModelDataCAD

using System;

public class ModelDataCAD
{
}