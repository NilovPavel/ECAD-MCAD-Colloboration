// File:    SpecificationDataCAD.cs
// Author:  nilov_pg
// Created: 9 августа 2019 г. 15:53:18
// Purpose: Definition of Class SpecificationDataCAD

using System;

public class SpecificationDataCAD
{
}