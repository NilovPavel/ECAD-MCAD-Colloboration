// File:    PerechenDataCAD.cs
// Author:  nilov_pg
// Created: 9 августа 2019 г. 15:51:52
// Purpose: Definition of Class PerechenDataCAD

using System;

public class PerechenDataCAD : IBuilderDataCAD
{
}