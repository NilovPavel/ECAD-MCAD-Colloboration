// File:    EskdSpecificationType.cs
// Author:  nilov_pg
// Created: 27 августа 2019 г. 9:33:53
// Purpose: Definition of Enum EskdSpecificationType

using System;

public enum EskdSpecificationType
{
   general,
   em
}