// File:    IBuilderDataCAD.cs
// Author:  nilov_pg
// Created: 9 августа 2019 г. 15:51:28
// Purpose: Definition of Interface IBuilderDataCAD

using System;

public interface IBuilderDataCAD
{
}