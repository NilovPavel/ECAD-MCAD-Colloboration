// File:    IHolePad.cs
// Author:  nilov_pg
// Created: 26 ноября 2018 г. 9:42:42
// Purpose: Definition of Interface IHolePad

using System;

public interface IHolePad
{
   IContour GetIContour();

}