// File:    Mask.cs
// Author:  nilov_pg
// Created: 9 августа 2019 г. 15:51:57
// Purpose: Definition of Class Mask

using System;

public class Mask
{
}