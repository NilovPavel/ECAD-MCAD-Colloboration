﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BoardSpace
{
    enum BendingLineParameters
    {
        Angle,
        Radius,
        FoldIndex,
        X1,
        Y1,
        X2,
        Y2
    };
}
